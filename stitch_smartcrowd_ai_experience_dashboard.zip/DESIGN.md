# Design System Strategy: The Luminescent Void

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Luminescent Void."** 

In a world of flat, generic SaaS templates, this system seeks to create a high-density, immersive environment that feels like a premium terminal from the future. We are moving away from traditional "boxed" layouts toward a digital ecosystem where depth is conveyed through light, blur, and tonal shifts rather than structural lines. 

The aesthetic is characterized by **Intentional Asymmetry** and **Editorial Scale**. We break the monotony of the grid by overlapping glass layers and using dramatic typography shifts. This is not just a dashboard; it is a high-performance instrument for intelligence.

---

## 2. Colors & Surface Logic
The palette is rooted in a deep, nocturnal foundation, punctuated by high-energy accents that mimic the glow of a neural network.

### Palette Strategy
- **Base Foundation:** `surface` (#0f131e) serves as our infinite canvas.
- **The Accents:** `primary` (#adc6ff) and `secondary` (#d0bcff) are used for "moments of intelligence"—CTAs, active states, and data visualizations.
- **The Glow:** Use `primary_container` and `secondary_container` with low opacity for ambient radial gradients behind key content to simulate light emission.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define sections. Boundaries must be established through:
1.  **Background Shifts:** Placing a `surface_container_low` card on a `surface` background.
2.  **Tonal Transitions:** Using subtle shifts between `surface_container` tiers to indicate hierarchy.
3.  **Negative Space:** Using the Spacing Scale to let the eye define groups.

### Surface Hierarchy & Nesting
Think of the UI as physical layers of frosted obsidian. 
- **Deepest:** `surface_container_lowest` (#0a0e19) for the global background or recessed areas.
- **Mid:** `surface_container` (#1b1f2b) for standard content blocks.
- **Top:** `surface_container_highest` (#313441) for interactive elements and floating modals.

### The "Glass & Gradient" Rule
To achieve the "Hackathon-ready" premium feel, use **Glassmorphism** for all floating elements. 
- **Recipe:** Fill: `surface_variant` at 40% opacity + Backdrop Blur: 20px. 
- **Signature Textures:** Main CTAs should use a linear gradient from `primary` (#adc6ff) to `secondary` (#d0bcff) at a 135-degree angle to provide a "metallic" light-reflecting quality.

---

## 3. Typography
Our typography is a dialogue between technical precision and bold editorial statements.

| Level | Token | Font Family | Size | Character |
| :--- | :--- | :--- | :--- | :--- |
| **Display** | `display-lg` | Space Grotesk | 3.5rem | High-impact, futuristic, bold. |
| **Headline**| `headline-md` | Space Grotesk | 1.75rem | Authoritative and structured. |
| **Title**   | `title-lg` | Inter | 1.375rem | Clean, professional, modern. |
| **Body**    | `body-md` | Inter | 0.875rem | High legibility for data. |
| **Label**   | `label-sm` | Inter | 0.6875rem | Utility-focused. |

**Technical Accents:** For code snippets or AI-generated strings, use **Consolas**. It grounds the futuristic aesthetic in developer-centric reality.

---

## 4. Elevation & Depth
Depth in this design system is an atmospheric quality, not a drop-shadow effect.

- **The Layering Principle:** Stack your containers. An inner card (`surface_container_high`) inside a section (`surface_container_low`) creates a natural "lift" without the need for old-fashioned shadows.
- **Ambient Shadows:** When an element must float (e.g., a dropdown), use an extra-diffused shadow. 
    *   *Shadow Color:* Use a 10% opacity version of `primary` or `secondary` to create a "glow" rather than a dark void.
- **The "Ghost Border" Fallback:** If a container requires definition against a similar background, use a **Ghost Border**: `outline_variant` (#424754) at 15% opacity. This provides a structural hint without "closing" the design.
- **Interactive Depth:** On hover, a component should transition from `surface_container` to `surface_bright` with a subtle increase in backdrop-blur intensity.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `secondary`). Text: `on_primary_fixed`. Roundedness: `full`.
- **Secondary:** Glass effect. Fill: `surface_variant` at 20% opacity. Ghost border enabled.
- **Tertiary:** No fill. Text: `primary`. Subtle 4px glow on hover.

### Input Fields
- **Styling:** Use `surface_container_low` with a bottom-only Ghost Border. 
- **Focus State:** The border animates to 100% opacity `primary`, and a subtle radial glow appears behind the input field.
- **Error State:** Use `error` (#ffb4ab) for text and a 5% `error_container` background tint.

### Cards & Lists
- **Rule:** **No Divider Lines.** 
- Use vertical white space (refer to the 8px grid) to separate items.
- For lists, use alternating backgrounds (`surface_container` vs `surface_container_low`) only if the data density is extremely high. Otherwise, let space do the work.

### Additional: The "Intelligence Chip"
- A selection chip using `secondary_container` with a tiny `secondary` dot to indicate AI-driven status or categorized data. Use `xl` (1.5rem) rounding for a pill-like appearance.

---

## 6. Do’s and Don’ts

### Do
- **Do** use asymmetric layouts. Place a large `display-lg` headline off-center to create visual tension.
- **Do** lean into the "Blur." Use large, soft mesh gradients in the background (using `primary` and `secondary` at 5% opacity) to create a sense of deep space.
- **Do** use `inverse_surface` for high-priority tooltips to make them "pop" against the dark theme.

### Don’t
- **Don't** use pure black (#000000) for large surfaces. It kills the depth. Use `surface` (#0f131e).
- **Don't** use standard "Drop Shadows." They feel dated. Use tonal layering or ambient glows.
- **Don't** use high-contrast white text for everything. Use `on_surface_variant` (#c2c6d6) for secondary text to maintain the "premium dark" hierarchy.
- **Don't** use sharp corners. Every interactive element must utilize the Roundedness Scale (minimum `md`: 0.75rem) to feel approachable and organic.